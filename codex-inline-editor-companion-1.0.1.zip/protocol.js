export const connectionPath=/^\/__codex_text_[a-f0-9]{48}\/extension-connect$/;
export const local=url=>url.protocol==='http:'&&url.hostname==='127.0.0.1'&&!url.username&&!url.password;
export function validateBinding(binding,source){
 const endpoint=new URL(binding.endpoint),target=new URL(binding.target);
 if(binding.kind!=='codex-preview-extension'||!/^[a-f0-9-]{36}$/i.test(binding.thread)||typeof binding.project!=='string'||binding.project.length>4096||!/^(\/|[A-Za-z]:[\\/])/.test(binding.project)||!/^[a-f0-9]{64}$/.test(binding.token)||!local(endpoint)||endpoint.origin!==source.origin||endpoint.pathname!==source.pathname.replace('/extension-connect','/send')||endpoint.search||endpoint.hash||!['http:','https:'].includes(target.protocol)||target.username||target.password) throw Error('Invalid editor connection.');
 return {kind:binding.kind,thread:binding.thread,project:binding.project,target:target.href,endpoint:endpoint.href,token:binding.token};
}
export function validateBatch(data){
 if(!data||!/^[a-zA-Z0-9-]{8,80}$/.test(data.id??'')||typeof data.path!=='string'||!data.path.startsWith('/')||data.path.length>2000||!Array.isArray(data.changes)||!data.changes.length||data.changes.length>50) throw Error('Invalid edit batch.');
 const batch={id:data.id,path:data.path,changes:data.changes.map(c=>{for(const k of ['selector','before','after'])if(typeof c[k]!=='string'||c[k].length>8000)throw Error('A text section is too large or invalid.');if(!c.selector||!c.before.trim()||c.before===c.after)throw Error('An edit is empty or unchanged.');return {selector:c.selector,before:c.before,after:c.after};})};
 if(new TextEncoder().encode(JSON.stringify(batch)).length>60000)throw Error('Send fewer or shorter changes.');return batch;
}
