import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';

// Observe only this send, in this exact chat. Queue acceptance alone is not a receipt.
export async function waitForReceipt({cli,thread,prompt,cwd,timeout=25000,interval=750,open=openHistory}) {
 const deadline=Date.now()+timeout;
 let reader;
 try {
  reader=await open({cli,cwd,deadline});
  do {
   const result=await reader.read(thread);
   if(result.data?.some(({item})=>item?.type==='userMessage' &&
     item.content?.filter(part=>part.type==='text').map(part=>part.text).join('\n').includes(prompt)))return true;
   const remaining=deadline-Date.now();
   if(remaining<=0)break;
   await delay(Math.min(interval,remaining));
  }while(Date.now()<deadline);
 }catch{/* Accepted sends must never become retryable failures because observation failed. */}
 finally{reader?.close();}
 return false;
}

function openHistory({cli,cwd,deadline}) {
 const child=spawn(cli,['app-server','--stdio'],{cwd,stdio:['pipe','pipe','pipe']});
 let buffer='',id=0,closed=false;const pending=new Map();
 function close(){if(closed)return;closed=true;for(const {reject,timer} of pending.values()){clearTimeout(timer);reject(Error('Receipt connection closed'));}pending.clear();child.stdin.destroy();child.kill();}
 child.once('error',close);child.once('exit',close);child.stdin.on('error',close);child.stderr.resume();
 child.stdout.on('data',chunk=>{
  buffer+=chunk;if(buffer.length>2*1024*1024){close();return;}
  let newline;
  while((newline=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,newline);buffer=buffer.slice(newline+1);
   try{const message=JSON.parse(line),request=pending.get(message.id);if(!request)continue;
    pending.delete(message.id);clearTimeout(request.timer);
    message.error?request.reject(Error('Receipt read unavailable')):request.resolve(message.result);
   }catch{/* Ignore unrelated protocol notifications. */}
  }
 });
 const ask=(method,params)=>new Promise((resolve,reject)=>{
  if(closed||Date.now()>=deadline)return reject(Error('Receipt deadline reached'));
  const requestId=++id;
  const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('Receipt read timed out'));},Math.min(4000,deadline-Date.now()));
  pending.set(requestId,{resolve,reject,timer});child.stdin.write(JSON.stringify({id:requestId,method,params})+'\n');
 });
 return (async()=>{try{
  await ask('initialize',{clientInfo:{name:'inline_editor_receipt',title:null,version:'1'},capabilities:{experimentalApi:true,requestAttestation:false}});
  child.stdin.write(JSON.stringify({method:'initialized'})+'\n');
  return {read:threadId=>ask('thread/items/list',{threadId,limit:50,sortDirection:'desc'}),close};
 }catch(error){close();throw error;}})();
}

// Rechecks never enqueue another message. Concurrent observers share the same read.
export async function refreshReceipt(receipt) {
 if(receipt.result.state!=='queued'||receipt.result.confirmed||!receipt.check)return;
 receipt.observing ||= Promise.resolve().then(receipt.check).catch(()=>false);
 const observing=receipt.observing;
 try{if(await observing)receipt.result.confirmed=true;}
 finally{if(receipt.observing===observing)receipt.observing=null;}
}
