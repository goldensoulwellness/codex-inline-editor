# Optional local companion

Node.js 20+, no dependencies. Keep all four files together.

Run from the intended Codex chat's terminal environment:

```sh
node /path/to/companion/connect.mjs --target https://your-site.example/page --project /absolute/path/to/source
```

The current `CODEX_THREAD_ID` identifies the recipient. If your environment does not expose it, supply `--thread` with that chat's exact verified UUID. Never guess or use the most recent chat. Verify the returned thread and project; open the returned `connectionURL` in the tab belonging to that chat. The extension returns to the original webpage.

Keep this program running while using Send. Stop with Ctrl+C. It listens only on 127.0.0.1 at a random port and uses a random per-session authorization token. A new tab requires its own connection; same-origin navigation retains the existing recipient. Close the tab or restart the browser to clear the binding. Preserve drafts before reconnecting.

Requires a Codex CLI exposing `codex queue --thread UUID --message TEXT`. Check `codex queue --help`. On macOS it can use the bundled ChatGPT app CLI; otherwise `codex` must be on PATH, or set `CODEX_PREVIEW_CLI` to the installed executable. CLI availability depends on your Codex version. Copy edits remains available without this companion.

Only a user click on Send requests delivery. Delivery is acknowledged when the CLI returns successfully, not when Codex has applied source changes. Check the chat after an uncertain result before retrying. This program never deploys or modifies website source itself.
